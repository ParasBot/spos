import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.Vector;

class MNTEntry {
    String name;
    int pp, kp, mdtp, alap;

    public MNTEntry(String name, int pp, int kp, int mdtp, int alap) {
        this.name = name;
        this.pp = pp;
        this.kp = kp;
        this.mdtp = mdtp;
        this.alap = alap;
    }
}

public class MacroPass2 {
    public static void main(String[] args) throws Exception {
        BufferedReader irb = new BufferedReader(new FileReader("intermediate.txt"));
        BufferedReader mdtb = new BufferedReader(new FileReader("mdt.txt"));
        BufferedReader alab = new BufferedReader(new FileReader("ala.txt"));
        BufferedReader mntb = new BufferedReader(new FileReader("mnt.txt"));
        FileWriter fr = new FileWriter("pass2.txt");

        HashMap<String, MNTEntry> mnt = new HashMap<>();
        HashMap<Integer, String> aptab = new HashMap<>();
        HashMap<String, Integer> aptabInverse = new HashMap<>();
        Vector<String> mdt = new Vector<>();
        Vector<String> ala = new Vector<>();

        // Load MDT file
        String line;
        while ((line = mdtb.readLine()) != null) {
            mdt.add(line);
        }

        // Load ALA file
        while ((line = alab.readLine()) != null) {
            ala.add(line);
        }

        // Load MNT file
        while ((line = mntb.readLine()) != null) {
            String[] parts = line.split("\\s+");
            if (parts.length >= 5) { // Check to ensure there are enough elements
                mnt.put(parts[0], new MNTEntry(parts[0], Integer.parseInt(parts[1]),
                        Integer.parseInt(parts[2]), Integer.parseInt(parts[3]),
                        Integer.parseInt(parts[4])));
            } else {
                System.out.println("Warning: Incorrect format in MNT line: " + line);
            }
        }

        // Process Intermediate file
        while ((line = irb.readLine()) != null) {
            String[] parts = line.split("\\s+");

            if (parts.length > 0 && mnt.containsKey(parts[0])) { // Check if it's a macro invocation
                MNTEntry mntEntry = mnt.get(parts[0]);
                int pp = mntEntry.pp;
                int kp = mntEntry.kp;
                int alap = mntEntry.alap;
                int mdtp = mntEntry.mdtp;
                int paramNo = 1;

                // Process positional parameters
                for (int i = 1; i <= pp && i < parts.length; i++) {
                    parts[i] = parts[i].replace(",", "");
                    aptab.put(paramNo, parts[i]);
                    aptabInverse.put(parts[i], paramNo);
                    paramNo++;
                }

                // Process keyword parameters
                int j = alap - 1;
                for (int i = 0; i < kp; i++) {
                    if (j < ala.size()) { // Bounds check for ala
                        String[] temp = ala.get(j).split("\t");
                        if (temp.length >= 2) {
                            aptab.put(paramNo, temp[1]);
                            aptabInverse.put(temp[0], paramNo);
                            j++;
                            paramNo++;
                        }
                    } else {
                        System.out.println("Warning: ALA index out of bounds for keyword parameters.");
                    }
                }

                // Handle remaining keyword parameters in input line
                for (int i = pp + 1; i < parts.length; i++) {
                    parts[i] = parts[i].replace(",", "");
                    String[] splits = parts[i].split("=");
                    if (splits.length == 2) {
                        String name = splits[0].replaceAll("&", "");
                        if (aptabInverse.containsKey(name)) {
                            aptab.put(aptabInverse.get(name), splits[1]);
                        }
                    }
                }

                // Substitute parameters in MDT
                int i = mdtp - 1;
                while (i < mdt.size() && !mdt.get(i).equalsIgnoreCase("MEND")) {
                    String[] splits = mdt.get(i).split("\\s+");
                    fr.write("+");
                    for (String split : splits) {
                        if (split.contains("(P,")) {
                            split = split.replaceAll("[^0-9]", "");
                            int paramIndex = Integer.parseInt(split);
                            if (aptab.containsKey(paramIndex)) {
                                fr.write(aptab.get(paramIndex) + "\t");
                            } else {
                                System.out.println("Warning: APTAB index not found for " + paramIndex);
                            }
                        } else {
                            fr.write(split + "\t");
                        }
                    }
                    fr.write("\n");
                    i++;
                }

                aptab.clear();
                aptabInverse.clear();
            } else {
                fr.write(line + "\n"); // Write non-macro lines as-is
            }
        }

        // Close all readers and writers
        fr.close();
        mntb.close();
        mdtb.close();
        alab.close();
        irb.close();

        System.out.println("Macro Pass-II Processing done. :)");
    }
}
